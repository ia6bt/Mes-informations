Inter (SIL OFL 1.1, rsms.me/inter) and DejaVu Sans Mono (free Bitstream Vera license), Latin subsets.
